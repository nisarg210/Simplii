<h2> Changes made in Phase 2 </h2>

<ol>
  <li>Landing page has been created.</li>
  <li>Database has been added to the system for better data management.</li>
  <li>Multi-user functionality added with usage of database.</li>
  <li>To facilitate multi-user functionality, login, sign-up and logout features are added.</li>
  <li>Resolved feature request of e-mail functionality. This allows users to receive list of tasks via e-mail.</li>
  <li>Fixed the time-stamp issue from previous phase.</li>
  <li>Multiple test cases added.
    <ul>
      <li>Login</li>
      <li>Signup</li>
      <li>Database Connection</li>
    </ul>
  </li>
  <li>Improved repository with multiple badges indicating development status of project.</li>
  <li>Added code coverage for the repository.</li>
</ol>
