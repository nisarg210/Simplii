## Getting started with analytics and recommendation of the user:

#### 1. Once the user is created and tasks are added by the user follow these steps

#### 2. Run this command on terminal in the directory where the file is stored to view the statistics of tasks
    python stats.py
    
#### 3. Run this command on terminal in the directory where the file is stored. This would allow user to view task recommendations in the web application
    python recommend.py

